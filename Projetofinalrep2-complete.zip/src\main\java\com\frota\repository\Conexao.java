package com.frota.repository;

import java.sql.Connection;
import java.sql.SQLException;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class Conexao {
    private static final String URL = "jdbc:mysql://localhost:3337/db_agrirent"
        + "?connectTimeout=5000&socketTimeout=30000&autoReconnect=true&useSSL=false&allowPublicKeyRetrieval=true";
    private static final String USUARIO = "root";
    private static final String SENHA = "";
    private static volatile HikariDataSource dataSource;

    private static synchronized HikariDataSource getDataSource() {
        if (dataSource == null || dataSource.isClosed()) {
            HikariConfig config = new HikariConfig();
            config.setJdbcUrl(URL);
            config.setUsername(USUARIO);
            config.setPassword(SENHA);
            config.setMaximumPoolSize(5);
            config.setMinimumIdle(1);
            config.setConnectionTimeout(10000);
            config.setInitializationFailTimeout(0); // nao falha no inicio, tenta lazy
            config.setConnectionTestQuery("SELECT 1");
            dataSource = new HikariDataSource(config);
        }
        return dataSource;
    }

    public static Connection getConnection() throws SQLException {
        return getDataSource().getConnection();
    }
}
